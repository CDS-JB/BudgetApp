# 09-mongo-restful-fetch-demo
Express Mongo Restful Demo with endpoints for Fetch / XHR
## For Nodemon
npm install -g nodemon
## API Testing 
Use POSTMAN for API Testing
